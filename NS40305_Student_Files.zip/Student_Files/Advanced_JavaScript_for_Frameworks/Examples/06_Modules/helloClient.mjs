import HelloWorld from './HelloWorld'

let helloWorld = new HelloWorld()

helloWorld.sayHello()