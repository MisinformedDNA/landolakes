export default class HelloWorld {

    sayHello() {

        console.log('Hello, World!')
    }
}