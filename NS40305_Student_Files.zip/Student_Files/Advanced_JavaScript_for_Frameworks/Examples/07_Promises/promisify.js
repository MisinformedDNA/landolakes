var util = require('util')
var setTimeoutPromise = util.promisify(setTimeout)

var p = setTimeoutPromise(1000, 'Timer expired')

p.then( (result) => console.log(result) )

console.log('After handler registration')