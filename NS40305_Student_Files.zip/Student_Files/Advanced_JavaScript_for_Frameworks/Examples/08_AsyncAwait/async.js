async function square(value) {

    return value * value
}

var p = square(5)

p.then( (result) => console.log(result) )

console.log('After handler registration')