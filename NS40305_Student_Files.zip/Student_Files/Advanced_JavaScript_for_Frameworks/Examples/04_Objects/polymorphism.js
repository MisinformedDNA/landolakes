// polymorphism.js
// Copyright © 2018 Next Step IT Training. All rights reserved.
//

var employee1 = {
    name: 'John Smith',
    hiredate: new Date('2003-07-01'),
    salary: 52000,
    calculatePay: function () { return (this.salary / 52).toFixed(2) }
}

var employee2 = {
    name: 'John Beale',
    salary: 72000,
    calculatePay: function () { return (this.salary / 52).toFixed(2) }
}

var employees = [ employee1, employee2 ]

for (let employee of employees) {

    console.log(`Employee ${employee.name} weekly salary === $${employee.calculatePay()}`)
}