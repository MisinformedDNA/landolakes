// NS20305 methods.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

var johnsmith = {

    name: 'John Smith',
    hiredate: new Date('2003-07-01'),
    salary: 52000,
    calculatePay: function () { return this.salary / 52 }
}

console.log(`John Smith's weekly pay is ${johnsmith.calculatePay()}`)