// NS20305 for-in.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

var johnsmith = {

    name: 'John Smith',
    hiredate: new Date('2003-07-01'),
    salary: 52000
}

for (property in johnsmith) {

    console.log(`${property}: ${johnsmith[property]}`)
}