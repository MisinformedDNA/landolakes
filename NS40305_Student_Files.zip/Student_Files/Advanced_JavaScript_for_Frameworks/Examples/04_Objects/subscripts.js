// NS20305 subscripts.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

var johnsmith = {

    name: 'John Smith',
    hiredate: new Date('2003-07-01'),
    salary: 52000
}

console.log(johnsmith)
console.log(`John Smith's hire date is ${johnsmith['hiredate']}}`)

johnsmith['employee notes'] = 'Very good leadership skills'
console.log(johnsmith)