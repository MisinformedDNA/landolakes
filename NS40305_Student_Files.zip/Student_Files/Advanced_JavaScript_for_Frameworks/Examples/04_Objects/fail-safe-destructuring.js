// fail-safe-destructuring.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//
// Extra variables in destructuring of both arrays and objects are left undefined.
//

let array = [ 1, 2, 3 ]
let object = { one: 1, two: 2, three: 3 }

let [ a, b, c, d ] = array

console.log(`a, b, c, d: ${a}, ${b}, ${c}, ${d}`)

let { one, two, three, four} = object

console.log(`one, two, three, four: ${one}, ${two}, ${three}, ${four}`)