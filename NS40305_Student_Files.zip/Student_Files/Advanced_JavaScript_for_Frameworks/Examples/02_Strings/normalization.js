// normalization.js
// Copyright © 2018 Next Step IT Training. All rights reserved.
//

let n = 5
let s = '5'

console.log(n + s)
console.log(n * s)
console.log(s * 1 + n)