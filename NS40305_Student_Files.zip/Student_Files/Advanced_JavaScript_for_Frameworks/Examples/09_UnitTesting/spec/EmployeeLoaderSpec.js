// EmployeeLoaderSpec.js
// Copyright © 2018 NextStep IT Training. All rights reserved.
//

require("jasmine")

const EmployeeLoader = require("../EmployeeLoader")

describe('EmployeeLoader Asynchronous Operation', () => {

    var dataLoader
    var employeeLoader

    beforeAll( () => {

        dataLoader = {

            getEmployees: async function() {

                return new Promise( (resolve, reject) => {

                    resolve( [ { id: 1, name: 'John Smith', hiredate: new Date('2003-07-01'), salary: 52000 } ] )
                })
            }
        }
    })

    beforeEach( () => {

        employeeLoader = new EmployeeLoader(dataLoader)
    })

    it('Should get the correct employee count', async (done) => {

        count = await employeeLoader.getEmployeeCount()

        expect(count).toBe(1)
        done()
    })
})