// CalculatorSpec.mjs
// Copyright © NextStep IT Training. All rights reserved.
//

require("jasmine")

const Calculator = require("../Calculator")

describe('Calculator Tests', () => {

    let calculator = null

    beforeEach( () => {

        calculator = new Calculator()
    })

    // Addition.

    it('adds 1 and 1', () => {

        expect(calculator.add(1, 1)).toBe(2)
    })

    it('adds 100 and 100', () => {

        expect(calculator.add(100, 100)).toBe(200)
    })

    it('refuses to add -1 and 1', () => {

        expect( () => calculator.add(-1, 1) ).toThrow()
    })

    it('refuses to add 1 and -1', () => {

        expect( () => calculator.add(1, -1) ).toThrow()
    })

    it('refuses to add 0 and 1', () => {

        expect( () => calculator.add(0, 1) ).toThrow()
    })

    it('refuses to add 1 and 0', () => {

        expect( () => calculator.add(1, 0) ).toThrow()
    })

    it('refuses to add 100 and 101', () => {

        expect( () => calculator.add(100, 101) ).toThrow()
    })

    it('refuses to add 101 and 100', () => {

        expect( () => calculator.add(101, 100) ).toThrow()
    })

    // Subtraction.

    it('subtracts 1 and 1', () => {

        expect(calculator.subtract(1, 1)).toBe(0)
    })

    it('subtracts 100 and 100', () => {

        expect(calculator.subtract(100, 100)).toBe(0)
    })

    it('refuses to substract -1 and 1', () => {

        expect( () => calculator.subtract(-1, 1) ).toThrow()
    })

    it('refuses to substract 1 and -1', () => {

        expect( () => calculator.subtract(1, -1) ).toThrow()
    })

    it('refuses to substract 0 and 1', () => {

        expect( () => calculator.subtract(0, 1) ).toThrow()
    })

    it('refuses to substract 1 and 0', () => {

        expect( () => calculator.subtract(1, 0) ).toThrow()
    })

    it('refuses to substract 100 and 101', () => {

        expect( () => calculator.subtract(100, 101) ).toThrow()
    })

    it('refuses to substract 101 and 100', () => {

        expect( () => calculator.subtract(101, 100) ).toThrow()
    })

    // Multiplication.

    it('multiplies 2 and 3', () => {

        expect(calculator.multiply(2, 3)).toBe(6)
    })

    it('multiplies 100 and 100', () => {

        expect(calculator.multiply(100, 100)).toBe(10000)
    })

    it('refuses to multiply -1 and 1', () => {

        expect( () => calculator.multiply(-1, 1) ).toThrow()
    })

    it('refuses to multiply 1 and -1', () => {

        expect( () => calculator.multiply(1, -1) ).toThrow()
    })

    it('refuses to multiply 0 and 1', () => {

        expect( () => calculator.multiply(0, 1) ).toThrow()
    })

    it('refuses to multiply 1 and 0', () => {

        expect( () => calculator.multiply(1, 0) ).toThrow()
    })

    it('refuses to multiply 100 and 101', () => {

        expect( () => calculator.multiply(100, 101) ).toThrow()
    })

    it('refuses to multiply 101 and 100', () => {

        expect( () => calculator.multiply(101, 100) ).toThrow()
    })

    // Division.

    it('divides 6 and 3', () => {

        expect(calculator.divide(6, 3)).toBe(2)
    })

    it('divides 100 and 100', () => {

        expect(calculator.divide(100, 100)).toBe(1)
    })

    it('refuses to divide -1 and 1', () => {

        expect( () => calculator.divide(-1, 1) ).toThrow()
    })

    it('refuses to divide 1 and -1', () => {

        expect( () => calculator.divide(1, -1) ).toThrow()
    })

    it('refuses to divide 0 and 1', () => {

        expect( () => calculator.divide(0, 1) ).toThrow()
    })

    it('refuses to divide 1 and 0', () => {

        expect( () => calculator.divide(1, 0) ).toThrow()
    })

    it('refuses to divide 100 and 101', () => {

        expect( () => calculator.divide(100, 101) ).toThrow()
    })

    it('refuses to divide 101 and 100', () => {

        expect( () => calculator.divide(101, 100) ).toThrow()
    })
})