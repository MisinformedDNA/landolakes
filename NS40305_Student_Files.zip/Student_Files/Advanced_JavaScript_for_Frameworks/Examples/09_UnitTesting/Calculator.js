// Calculator.js
// Copyright © NextStep IT Training. All rights reserved.
//

class Calculator {

    add(a, b) {

        this.checkConstraints(a, b)

        let result = a + b
        
        return result
    }

    checkConstraints(a, b) {
        
        if (a <= 0 || b <= 0 || a > 100 || b > 100) {

            throw new Error('parameters must be between 1 and 100')
        }
    }

    divide(a, b) {

        this.checkConstraints(a, b)

        let result = a / b
        
        return result
    }

    multiply(a, b) {

        this.checkConstraints(a, b)

        let result = a * b
        
        return result
    }

    subtract(a, b) {

        this.checkConstraints(a, b)

        let result = a - b
        
        return result
    }
}

module.exports = Calculator