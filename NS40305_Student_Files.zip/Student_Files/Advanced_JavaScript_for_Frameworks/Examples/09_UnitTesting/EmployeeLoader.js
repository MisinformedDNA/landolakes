// EmployeeLoader.js
// Copyright © 2018 NextStep IT Training. All rights reserved.
//

class EmployeeLoader {

    constructor(dataLoader) {

        this.loader = dataLoader
    }

    async getEmployeeCount() {

        let employees = await this.loader.getEmployees()

        return employees.length
    }
}

module.exports = EmployeeLoader