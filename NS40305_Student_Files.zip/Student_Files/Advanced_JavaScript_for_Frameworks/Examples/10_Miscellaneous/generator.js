class EveryOtherNumber {

    constructor(start) {

        this.start = start
    }

    *[Symbol.iterator]() {

        while (true) {

            yield this.start

            this.start += 2
        }
    }
}

for (let x of new EveryOtherNumber(5)) {

    if (x > 15) {

        break
    }

    console.log(x)
}