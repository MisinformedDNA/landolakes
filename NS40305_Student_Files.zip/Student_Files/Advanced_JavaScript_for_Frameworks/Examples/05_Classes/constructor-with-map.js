// NS20305 constructor-with-map.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(source) {

        if (source) {

            Object.assign(this, source)
        }
    }
}

var employee = new Employee({ name: 'John Smith', hiredate: new Date('2003-07-01'), salary: 52000 })

console.log(employee)