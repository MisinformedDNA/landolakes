// NS20305 static.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(source) {

        if (source) {

            Object.assign(this, source)
        }
    }

    static employeeTaxRate() {
        
        return 0.25
    }
}

class SalaryEmployee extends Employee {

}

var johnsmith = new SalaryEmployee({ name: 'John Smith', hiredate: new Date('2003-07-01'), salary: 52000 })

console.log(`johnsmith.employeeTaxRate: ${ johnsmith.employeeTaxRate }`)
console.log(`SalaryEmployee.employeeTaxRate: ${ SalaryEmployee.employeeTaxRate }`)
console.log(`Employee.employeeTaxRate: ${ Employee.employeeTaxRate }`)