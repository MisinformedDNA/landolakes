// NS20305 extend.js
// Copyright (C) 2018 NextStep IT Training. All rights reserved.
//

class Base {

    toString() { return 'class Base' }
}

class A extends Base {
}

class B extends Base {
}

var a = new A()
var b = new B()

console.log(`a.toString(): ${ a.toString() }`)
console.log(`a instanceof A: ${ a instanceof A }`)
console.log(`a instanceof Base: ${ a instanceof Base }`)
console.log(`a instanceof B: ${ a instanceof B }`)

console.log(`b.toString(): ${ b.toString() }`)
console.log(`b instanceof B: ${ b instanceof B }`)
console.log(`b instanceof Base: ${ b instanceof Base }`)
console.log(`b instanceof A: ${ b instanceof A }`)