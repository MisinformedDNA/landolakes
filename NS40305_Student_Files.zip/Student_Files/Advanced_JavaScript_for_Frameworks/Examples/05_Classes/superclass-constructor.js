// NS20305 extend.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor() {

        if (source) {

            Object.assign(this, source)
        }

        this.name = this.name ? this.name : ''
        this.hiredate = this.hiredate ? this.hiredate : null
    }
}

class SalaryEmployee extends Employee {

    constructor(source) {

        super(source)
        this.salary = this.salary ? this.salary : 0
    }

    calculatePay() {

        return this.salaray / 52
    }
}

class HourlyEmployee extends Employee {

    constructor(source) {

        super(source)
        this.hourlyRate = this.hourlyRate ? this.hourlyRate : 0
        this.hoursPerWeek = this.hoursPerWeek ? this.hoursPerWeek : 0
    }

    calculatePay() {

        return this.hourlyRate * this.hoursPerWeek
    }
}