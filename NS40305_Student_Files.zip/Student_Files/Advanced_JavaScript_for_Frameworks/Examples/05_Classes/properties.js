// NS20305 properties.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(source) {

        this.name = ''
        this.hiredate = null
        this.salary = 0

        if (source) {

            Object.assign(this, source)
        }
    }

    get salary() {
        
        return this._salary
    }

    set salary(value) {

        if (value < 0) {

            throw new RangeError('Salary must be >= 0')
        }

        this._salary = value
    }
}

var employee = new Employee({ name: 'John Smith', hiredate: new Date('2003-07-01'), salary: -1 })