// NS20305 constructor.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(name, hiredate, salary) {

        this.name = name
        this.hiredate = hiredate
        this.salary = salary
    }
}

var johnsmith = new Employee('John Smith', new Date('2003-07-01'), 52000)

console.log(johnsmith)