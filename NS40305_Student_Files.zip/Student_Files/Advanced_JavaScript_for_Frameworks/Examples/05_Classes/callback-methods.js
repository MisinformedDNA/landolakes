// NS20305 callback-methods.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(source) {

        if (source) {

            Object.assign(this, source)
        }

        this.employmentLength = this.employmentLength.bind(this)

        setInterval(this.employmentLength, 1000)
    }

    employmentLength() {

        console.log(`seconds employed: ${ Math.floor(((new Date()) - this.hiredate) / 1000) }`)
    }
}

var johnsmith = new Employee({ name: 'John Smith', hiredate: new Date('2003-07-01'), salary: 52000 })