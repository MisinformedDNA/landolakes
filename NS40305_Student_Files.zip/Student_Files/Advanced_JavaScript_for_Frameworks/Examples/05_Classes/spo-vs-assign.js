// spo-vs-assign
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//
// This is a performance test comparing Reflect.setPrototypeOf vs
// Object.assign using an object passed to the constructor. The documentation
// is correct, on the machine tested using Reflect.setPrototypeOf took
// an average of .16ms, while using Object.assign averaged .05ms. That
// is above a 3-1 difference.
//

const { PerformanceObserver, performance } = require('perf_hooks');

class Basis {

    constructor(src) {

        Object.assign(this, src)
    }

    get something() {

        return this._something
    }

    set something(value) {

        this._something = value
    }
}

// The source object to convert, as if it came as JSON from an AJAX call.

let s = { _something: 'Something!' }

// Start performance monitoring

const observer = new PerformanceObserver((list) => {
    
    console.log(list.getEntries())
})

observer.observe({ entryTypes: ['measure'] });
  
// Use setPrototypeOf to change the __proto__ for the object to the Basis class.

performance.mark('A')

Reflect.setPrototypeOf(s, Basis.prototype)

// Use the constructor with Object.Assign to create a new object of the Basis class.
// This is the preferred method anyways; setPrototypeOf requires that we populate the
// underlying private field so that the get method works; Object.assign allows a
// source with fields matching the properties (get/set) to be used, and that is what
// would really happen in the data returned from an AJAX call.

performance.mark('B')

let sPrime = new Basis(s)

performance.mark('C')

// Log the property from the two objects, just to prove that they both work.

console.log(`s.somethingToString = ${s.something}`)
console.log(`sPrime.somethingToString = ${sPrime.something}`)

// Measure and log the performance. When these tests were run as the script was developed,
// the duration of A to B (Reflect.setPrototypeOf) was consistently in the 0.15-0.16 millisecond
// range, and the duration of B to C (Object.assign) was consistently around 0.5 milliseconds.
// This simply confirms the documentation that setPrototypeOf is an expensive operation.

console.log('Measurements between marks:')
performance.measure('A to B', 'A', 'B')
performance.measure('B to C', 'B', 'C')

// Close the observer.

observer.disconnect()