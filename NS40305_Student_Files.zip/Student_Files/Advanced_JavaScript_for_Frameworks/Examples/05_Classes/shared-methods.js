// NS20305 shared-methods.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

class Employee {

    constructor(source) {

        this.name = ''
        this.hiredate = null
        this.salary = 0

        if (source) {

            Object.assign(this, source)
        }
    }

    calculatePay() {
        
        return this.salary / 52
    }
}

var johnsmith = new Employee({ name: 'John Smith', hiredate: new Date('2003-07-01'), salary: 52000 })
var johnrolfe = new Employee({ name: 'John Rolfe', hiredate: new Date('2003-06-30'), salary: 68000 })

console.log(johnsmith)
console.log(`John Smith's weekly pay is $${ johnsmith.calculatePay().toFixed(2) }`)

console.log(johnrolfe)
console.log(`John Rolfe's weekly pay is $${ johnrolfe.calculatePay().toFixed(2) }`)

console.log(`johnsmith.calculatePay === johnrobles.calculatePay: ${ johnsmith.calculatePay === johnrolfe.calculatePay }`)