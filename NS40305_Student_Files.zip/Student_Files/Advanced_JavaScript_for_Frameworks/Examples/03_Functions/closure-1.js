// closure.js
// Copyright © NextStep IT Training. All rights reserved.
//

function f() {

    console.log('Function f')

    function t() {

        console.log('Function t')
    }

    setTimeout(t, 1000)

    console.log('Function f: timer set')
}

f()
console.log('After function f call')