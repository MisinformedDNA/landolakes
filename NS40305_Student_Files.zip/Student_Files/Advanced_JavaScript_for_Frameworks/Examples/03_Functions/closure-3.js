// closure-3.js
// Copyright © Next Step IT Training. All rights reserved.
//

function f(message, timeout) {

    setTimeout(function () {

        console.log(message)

    }, timeout)
}

f('Timer expired', 1000)