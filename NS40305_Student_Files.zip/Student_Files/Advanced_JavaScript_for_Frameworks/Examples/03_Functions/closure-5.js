// closure-3.js
// Copyright © Next Step IT Training. All rights reserved.
//

function f(message, timeout) {

    var localvariable = 10

    setTimeout(() => {

        console.log(message, `First timer localvariable ===  ${localvariable}`)
        localvariable++

    }, timeout)

    setTimeout(() => {

        console.log(message, `Second Timer localvariable === ${localvariable}`)
        localvariable++

    }, timeout + 1000)
}

f('Timer expired', 1000)