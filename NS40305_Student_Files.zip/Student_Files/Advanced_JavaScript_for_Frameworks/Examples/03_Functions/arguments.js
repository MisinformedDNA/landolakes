function f(a, b) {

    console.log(arguments.length)
    console.log(arguments)
}

a(1, 2, 3)