
function f(a, b, ...c) {

    console.log(`a: ${a}, b: ${b}, c: ${c}`)
}

f(1, 2, 3, 4)