function f(a, b, c = 5) {

    console.log(`a: ${a}, b: ${b}, c: ${c}`)    
}

f(1, 2)