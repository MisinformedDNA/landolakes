'use strict'

function f(a, b) {

    arguments = [ a, b ]
}

f(1, 2)