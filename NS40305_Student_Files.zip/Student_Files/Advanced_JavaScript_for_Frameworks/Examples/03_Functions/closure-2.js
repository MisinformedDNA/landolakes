// closure-2.js
// Copyright © Next Step IT Training. All rights reserved.
//

function f() {

    setTimeout(function () {

        console.log('Timer expired')
    }, 1000)
}

f()