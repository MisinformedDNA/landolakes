// helloworld.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

console.log('Hello, World!')