// while.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let a = [ 1, 2, 3 ]

console.log('while:')

let i = 0

while (i < a.length) {

    console.log('a[' + i + '] == ' + a[i])
    ++i
}

console.log('do ...while:')

i = 0

do {

    console.log('a[' + i + '] == ' + a[i])
    ++i
    
} while (i < a.length)