// NS20305 datatypes.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

b = true
console.log(b + ': ' + typeof b)

n = 42
console.log(n + ': ' + typeof n)

r = 42.5
console.log(r + ': ' + typeof r)

s = 'Hello, World!'
console.log(s + ': ' + typeof s)

d = new Date()
console.log(d + ': ' + typeof d)
console.log('d instanceof Date: ' + (d instanceof Date))
console.log('d instanceof String: ' + (d instanceof String))

d2 = new Date
console.log(d2 + ': ' + typeof d2)
console.log('d2 instanceof Date: ' + (d instanceof Date))