// const.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

const x = 5
const y = x * 2

x = 6