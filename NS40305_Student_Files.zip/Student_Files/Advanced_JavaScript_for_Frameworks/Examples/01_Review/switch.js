// switch.js
// Copyright (c) 2018 NextStep IT Training. All Rights Reserved.
//

let x = 5

switch (x) {

    case 1:
        console.log('1')
        break
    
    case 2:
    case 3:
    case 4:
        console.log('2 or 3 or 4')
        break

    case '5':
        console.log("'5'")
        break

    case 5:
        console.log(5)
        break

    default:
        console.log('something else')
}