// iife.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let a = 42
let x = 43;

( function () {

    let a = 5
    let x = 5
    let y = square(x)

    console.log('a == ' + a + ', b == ' + b + ', x == ' + x + ', y == ' + y)

    function square(v) {

        {
            a = v * v
            b = v * v
            let x = v * v
        }

        return x  // uses the global x!
    }

} ).call()

console.log('a == ' + a + ', x == ' + x)