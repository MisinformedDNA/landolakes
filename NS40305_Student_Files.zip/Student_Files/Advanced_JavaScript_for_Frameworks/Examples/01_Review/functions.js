// functions.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let x = 5
let y = square(x)

console.log('x == ' + x + ', y == ' + y)

function square(v) {

    v = v * v
    return v
}