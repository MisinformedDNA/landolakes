// compare.js
// Copyright © 2018 Next Step IT Training. All rights reserved.
//

let x = 5
let y = '5'

console.log(x == y) // true
console.log(x === y) // false

console.log(x != y) // false
console.log(x !== y) // true

console.log(x >= y)
console.log(x <= y)