// if.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let x = 42

if (x) {

    console.log('x == ' + x)
    
} else {

    console.log('not x')
}