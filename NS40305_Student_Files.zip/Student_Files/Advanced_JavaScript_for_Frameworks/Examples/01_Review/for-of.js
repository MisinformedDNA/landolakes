// NS40305 for-of.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let a = [ 1, 2, 3 ]

for (let v of a) {

    console.log('v == ' + v)
}