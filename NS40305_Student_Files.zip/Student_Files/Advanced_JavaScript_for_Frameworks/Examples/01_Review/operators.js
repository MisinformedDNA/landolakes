// NS20305 operators.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

console.log('1 + 2: ' + (1 + 2))
console.log('1 + 2 * 3: ' + (1 + 2 * 3))
console.log('(1 + 2) * 3: ' + ((1 + 2) * 3))
console.log('5 / 2: ' + (5 / 2))
console.log("'2' * '3': " + ('2' * '3'))
console.log("'2' * 3: " + ('2' * 3))
console.log("'2' + 3: " + ('2' + 3))