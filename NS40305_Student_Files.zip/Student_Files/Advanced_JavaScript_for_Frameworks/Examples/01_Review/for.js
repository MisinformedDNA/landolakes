// for.js
// Copyright (c) 2018 NextStep IT Training. All rights reserved.
//

let a = [ 1, 2, 3 ]

for (let i = 0; i < a.length; ++i) {

    console.log('a[' + i + '] == ' + a[i])
}