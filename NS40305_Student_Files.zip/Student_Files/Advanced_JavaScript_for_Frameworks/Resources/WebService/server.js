// NT40801 Resources/WebService/server.js
//

(function() {

    var Server = require('./App/Server')

    let server = new Server()

}).call(this)