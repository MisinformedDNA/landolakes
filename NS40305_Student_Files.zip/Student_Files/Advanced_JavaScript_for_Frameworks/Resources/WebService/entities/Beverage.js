// NT40801 Resources/WebService/events/Beverage.js
//

class Beverage {
    
    constructor(obj) {

        Object.assign(this, obj)
    }
}

module.exports = exports = Beverage