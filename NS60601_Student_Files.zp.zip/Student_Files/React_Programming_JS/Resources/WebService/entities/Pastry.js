// NT80101 React/Resources/WebService/events/Pastry.js
//

class Pastry {
    
    constructor(obj) {

        Object.assign(this, obj)
    }
}

module.exports = exports = Pastry